#!/usr/bin/env python3
"""AES-128, byte-oriented reference implementation.

Capture note: a subset of experiments suffered a SINGLE-BYTE disturbance
immediately before MixColumns in round nine. Trace collection was unattended:
not every marked experiment really contains that fault.
"""

SBOX = tuple(bytes.fromhex('''
63 7c 77 7b f2 6b 6f c5 30 01 67 2b fe d7 ab 76
ca 82 c9 7d fa 59 47 f0 ad d4 a2 af 9c a4 72 c0
b7 fd 93 26 36 3f f7 cc 34 a5 e5 f1 71 d8 31 15
04 c7 23 c3 18 96 05 9a 07 12 80 e2 eb 27 b2 75
09 83 2c 1a 1b 6e 5a a0 52 3b d6 b3 29 e3 2f 84
53 d1 00 ed 20 fc b1 5b 6a cb be 39 4a 4c 58 cf
d0 ef aa fb 43 4d 33 85 45 f9 02 7f 50 3c 9f a8
51 a3 40 8f 92 9d 38 f5 bc b6 da 21 10 ff f3 d2
cd 0c 13 ec 5f 97 44 17 c4 a7 7e 3d 64 5d 19 73
60 81 4f dc 22 2a 90 88 46 ee b8 14 de 5e 0b db
e0 32 3a 0a 49 06 24 5c c2 d3 ac 62 91 95 e4 79
e7 c8 37 6d 8d d5 4e a9 6c 56 f4 ea 65 7a ae 08
ba 78 25 2e 1c a6 b4 c6 e8 dd 74 1f 4b bd 8b 8a
70 3e b5 66 48 03 f6 0e 61 35 57 b9 86 c1 1d 9e
e1 f8 98 11 69 d9 8e 94 9b 1e 87 e9 ce 55 28 df
8c a1 89 0d bf e6 42 68 41 99 2d 0f b0 54 bb 16'''))
INV = tuple(SBOX.index(i) for i in range(256))
MIX = ((2, 3, 1, 1), (1, 2, 3, 1), (1, 1, 2, 3), (3, 1, 1, 2))

def xtime(b):
    return ((b << 1) ^ (0x1b if b & 128 else 0)) & 255

def gm(a,b):
    v = 0
    while b:
        if b & 1: v ^= a
        a = xtime(a)
        b >>= 1
    return v

def key_expand(key):
    if len(key) != 16: raise ValueError('AES-128 key')
    w = [list(key[i:i+4]) for i in range(0,16,4)]
    rc = 1
    for i in range(4,44):
        t = w[-1][:]
        if i % 4 == 0:
            t = [SBOX[x] for x in (t[1:] + t[:1])]
            t[0] ^= rc
            rc = xtime(rc)
        w.append([w[-4][j] ^ t[j] for j in range(4)])
    return [sum(w[4*r:4*r+4], []) for r in range(11)]

def encrypt(key, plaintext, fault=None):
    """fault: optional (column,row,nonzero_byte) before round 9 MixColumns."""
    if len(plaintext) != 16: raise ValueError('block')
    rk = key_expand(key)
    s = [a ^ b for a,b in zip(plaintext,rk[0])]
    for rnd in range(1,11):
        s = [SBOX[x] for x in s]
        s = [s[4*((c+r)%4)+r] for c in range(4) for r in range(4)]
        if rnd != 10:
            if rnd == 9 and fault is not None:
                c,r,v = fault
                s[4*c+r] ^= v
            tmp = s[:]
            for c in range(4):
                for r in range(4):
                    s[4*c+r] = 0
                    for j in range(4):
                        s[4*c+r] ^= gm(MIX[r][j],tmp[4*c+j])
        s = [a ^ b for a,b in zip(s,rk[rnd])]
    return bytes(s)
